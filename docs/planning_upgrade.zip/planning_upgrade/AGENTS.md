# Palm Island Assistant Instructions

- Before coding, read `docs/PROJECT_MEMORY.md` sections **Current Status**,
  **Locked Decisions**, and **Next Work Item**. Read only other sections
  needed for the assigned task; avoid loading the archived GDD by default.
- For campaign, movement, task, inventory, weapon, map, obstacle, or enemy
  planning/implementation, read the matching section of
  `docs/MASTER_GAMEPLAY_BLUEPRINT.md`.
- For movement, camera, combat feel, interaction feedback, effects, or any
  "make it cooler/smoother" task, read `docs/GAME_FEEL_AND_SIGNATURE_PLAN.md`.
  Keep tunable numbers in `src/tuning.h`; change one number per tuning pass.
  Signature mechanics there are proposals: build one only after the user
  approves it and the Feel Gate has passed.
- Treat proposed HP, damage, food, material counts, and shop prices there as
  untested starting points, not final balance. Keep crafting limited to the
  approved small fixed tool set; do not add generic recipes or material
  grinding.
- Treat `docs/PROJECT_MEMORY.md` as the current source of truth. Archived
  planning documents and old GDD material do not override it.
- Work in small, playable increments. Do not attempt to implement the whole
  game or multiple roadmap phases in one change.
- Inspect the existing code before editing. Preserve working behavior, make
  the smallest complete change, and build the Windows target after code edits.
- Report what changed, the exact validation performed, and any remaining
  blockers. Do not claim a feature works unless it was verified.
- When implementation or a decision changes project state, update the matching
  status/decision in `docs/PROJECT_MEMORY.md`. Keep the handoff concise.
- Do not introduce external packages, large systems, or production assets
  without a clear need and an explicit plan.

See `README.md` for the short project overview and Windows build commands.
