# Palm Island — The Forgotten Coast

Palm Island is a **single-player 2D exploration adventure** built in C11 with
Raylib 5.5. You play as Ichigo, an outsider whose family symbol is connected
to a quiet, mysterious island. The intended game is about noticing, exploring,
and understanding the island—not grinding or constant combat.

> **Honest status:** this is not the complete game or the planned Forgotten
> Jungle vertical slice. The previous side-scrolling prototype was removed;
> the current executable is a small top-down movement test room (pixel-scaled
> tile map and an eight-way walking character). Collision, camera, props,
> authored levels, enemies, combat, dialogue, audio, and saving are not
> implemented.
>
> **Direction:** the game is planned as top-down 2D pixel art with
> eight-direction movement and 3D-like depth cues (layering, occlusion, and
> stairs/ramps between elevation layers). A movement test room is the next
> implementation milestone.

## Start here

- **AI/developer project memory and build plan:** [`docs/PROJECT_MEMORY.md`](docs/PROJECT_MEMORY.md)
- **Detailed campaign and gameplay blueprint:** [`docs/MASTER_GAMEPLAY_BLUEPRINT.md`](docs/MASTER_GAMEPLAY_BLUEPRINT.md)
- **Movement feel, measurable tests, and signature-mechanic proposals:** [`docs/GAME_FEEL_AND_SIGNATURE_PLAN.md`](docs/GAME_FEEL_AND_SIGNATURE_PLAN.md)
- **Rules for coding assistants:** [`AGENTS.md`](AGENTS.md)
- **Concept-art/source asset notes:** [`docs/ASSET_INDEX.md`](docs/ASSET_INDEX.md)
- **Archived original design:** [`docs/source/ORIGINAL_GAME_DESIGN.txt`](docs/source/ORIGINAL_GAME_DESIGN.txt)

The project memory is canonical for current status, decisions, and next steps.
The gameplay blueprint and game-feel plan provide detailed supporting
specifications; proposals in those documents do not become implementation
requirements until approved.

## Build and run on Windows

Requirements: CMake 3.16+, MSYS2 MinGW64 toolchain, and internet access for
the first Raylib download. Open PowerShell in this project folder:

```powershell
$env:Path = "C:\msys64\mingw64\bin;C:\msys64\usr\bin;$env:Path"
cmake -S . -B build -G "MinGW Makefiles" -DCMAKE_BUILD_TYPE=Debug
cmake --build build --parallel 4
.\build\PalmIsland.exe
```

If CMake reports that the build directory was configured with another
generator, remove only the generated `build` directory and configure again:

```powershell
Remove-Item -Recurse -Force build
cmake -S . -B build -G "MinGW Makefiles" -DCMAKE_BUILD_TYPE=Debug
cmake --build build --parallel 4
.\build\PalmIsland.exe
```

The `build` directory is generated and ignored by Git. The first configure
downloads Raylib 5.5 into `build/_deps`; subsequent builds reuse it.

## Current executable

The previous side-scrolling prototype has been removed. The current executable
is a top-down movement test room: walk Ichigo around a 320×180 pixel-art scene.
There is no collision yet, so he can walk through cliffs and water; only the
room edges stop him.

| Action | Keyboard | Controller |
|---|---|---|
| Move (8 directions) | WASD or arrow keys | Left stick / D-pad |
| Debug overlay (FPS, speed, position) | F3 | — |
| Borderless windowed | F11 | — |
| Quit | Esc | — |

## Project layout

```text
AGENTS.md                 Assistant behavior and memory entry point
src/main.c                Window, 320x180 canvas, fixed-step loop, asset lookup
src/tuning.h              Movement, loop, and canvas tuning values
src/player.[ch]           Eight-way movement, facing, animation (collision planned: M3)
src/room.[ch]             Tile room drawing (solid tiles and ramp logic planned: M3/M6)
src/input.[ch]            Keyboard and gamepad movement input
src/camera.[ch]            Planned room-bounded camera
src/render.[ch]            Planned pixel-art scene rendering and depth ordering
assets/concept_art/       Visual references and art guide
assets/sprites/           Starter player and prop sprites
assets/tilesets/          Starter 16x16 tileset
assets/previews/          Rendered scene previews
assets/source_packs/      Bundled reference archives
tools/generate_assets.py  Starter art generator
docs/PROJECT_MEMORY.md    Current canonical design, status, and work plan
docs/MASTER_GAMEPLAY_BLUEPRINT.md
                          Detailed map-by-map gameplay feature plan
docs/GAME_FEEL_AND_SIGNATURE_PLAN.md
                          Movement targets, Feel Gate, and unapproved mechanic proposals
docs/ASSET_INDEX.md       Asset reference and usage notes
docs/source/              Historical source documents
build/                    Generated files; do not edit by hand
```

For the full status, design decisions, incremental roadmap, test gates, and
AI handoff format, read [`docs/PROJECT_MEMORY.md`](docs/PROJECT_MEMORY.md).
